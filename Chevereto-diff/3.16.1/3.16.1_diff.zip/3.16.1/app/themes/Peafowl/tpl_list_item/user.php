<div class="list-item fixed-size c%COLUMN_SIZE_USER% gutter-margin-right-bottom" data-type="user">
	<a href="%USER_URL%" class="list-item-image fixed-size" %tpl_list_item/user_background_image%>
		<div class="list-item-avatar-cover image-container">
		%tpl_list_item/user_cover_empty%
		%tpl_list_item/user_cover_image%
		</div>
	</a>
	<div class="list-item-desc">
		<div class="list-item-desc-title"><a class="list-item-desc-title-link" href="%USER_URL%">%USER_NAME%</a><span class="display-block font-size-small">%USER_USERNAME%</span></div>
		<div class="position-absolute right-10 text-align-right"><span>%USER_IMAGE_COUNT%</span><span class="display-block font-size-small">%USER_IMAGE_COUNT_LABEL%</span></div>
	</div>
</div>