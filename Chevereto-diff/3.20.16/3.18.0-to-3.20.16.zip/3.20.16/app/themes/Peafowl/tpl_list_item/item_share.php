<div class="list-item-share" data-action="share">
	<span class="btn-icon btn-share fas fa-share-alt"></span>
</div>