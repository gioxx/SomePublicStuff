<?php if (!defined('access') or !access) {
    die('This file cannot be directly accessed.');
} ?>